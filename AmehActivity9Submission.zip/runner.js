// import main
const main = require("./main")
// set date under study
const dateUnderStudy = { month: 2, day: 16, year: 2024 };
// run main
console.log(main(dateUnderStudy))
